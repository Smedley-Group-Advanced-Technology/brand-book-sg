# Colour and theme tokens

Generated from the brand book's tokens.json by npm run kit. Use the CSS in `assets/tokens.css`.

## Fixed colours, the same in both themes

| Token | Value |
|---|---|
| `--sg-ink` | #000000 |
| `--sg-deep-navy` | #222A35 |
| `--sg-slate` | #333F50 |
| `--sg-steel` | #44546A |
| `--sg-mist` | #8497B0 |
| `--sg-pale-blue` | #ABC0E4 |
| `--sg-cloud` | #D6DCE5 |
| `--sg-plate` | #BFBFBF |
| `--sg-canvas` | #F0F0F0 |
| `--sg-off-white` | #F3F2F2 |
| `--sg-white` | #FFFFFF |
| `--sg-caption` | #9AA0A8 |
| `--sg-signal-positive` | #00B050 |
| `--sg-signal-positive-tint` | #E2F0D9 |
| `--sg-signal-negative` | #C00000 |
| `--sg-signal-negative-tint` | #FBE5D6 |
| `--sg-product-blue` | #ADB9CA |

## Light theme (the default)

| Token | Value |
|---|---|
| `--sg-text` | #000000 |
| `--sg-inv` | #FFFFFF |
| `--sg-ground` | #FFFFFF |
| `--sg-panel` | #F7F7F7 |
| `--sg-dim` | #333F50 |
| `--sg-faint` | #44546A |
| `--sg-rule` | rgba(0,0,0,.14) |
| `--sg-field` | #FFFFFF |
| `--sg-border` | rgba(68,84,106,.45) |
| `--sg-accent` | #44546A |
| `--sg-positive` | #007A3D |
| `--sg-positive-tint` | #E2F0D9 |
| `--sg-negative` | #C00000 |
| `--sg-negative-tint` | #FBE5D6 |
| `--sg-quiet-tint` | #D6DCE5 |
| `--sg-selected` | linear-gradient(135deg,#000000 0%,#222A35 100%) |
| `--sg-selected-hover` | linear-gradient(135deg,#222A35 0%,#333F50 100%) |
| `--sg-selected-edge` | linear-gradient(180deg,#8497B0 0%,#ABC0E4 53%,#333F50 100%) |
| `--sg-on-selected` | #FFFFFF |

## Dark theme, and anything inside `.sg-dark`

| Token | Value |
|---|---|
| `--sg-text` | #FFFFFF |
| `--sg-inv` | #000000 |
| `--sg-ground` | #10141A |
| `--sg-panel` | #171C24 |
| `--sg-dim` | #D6DCE5 |
| `--sg-faint` | #8497B0 |
| `--sg-rule` | rgba(171,192,228,.28) |
| `--sg-field` | rgba(255,255,255,.04) |
| `--sg-border` | rgba(171,192,228,.38) |
| `--sg-accent` | #ABC0E4 |
| `--sg-positive` | #4CD98A |
| `--sg-positive-tint` | rgba(0,176,80,.16) |
| `--sg-negative` | #FF8A8A |
| `--sg-negative-tint` | rgba(192,0,0,.24) |
| `--sg-quiet-tint` | rgba(171,192,228,.14) |
| `--sg-selected` | linear-gradient(#ABC0E4,#ABC0E4) |
| `--sg-selected-hover` | linear-gradient(#C7D5EE,#C7D5EE) |
| `--sg-selected-edge` | linear-gradient(#ABC0E4,#ABC0E4) |
| `--sg-on-selected` | #000000 |

## The signature surface

`--sg-surface`: 45 degrees, #000000 to #222A35. `--sg-edge`: a 1 px stroke, #8497B0 0%, #ABC0E4 53%, #333F50 100%, top to foot. `.sg-surface` applies both.

## Radii

| Token | Value |
|---|---|
| `--sg-radius-control` | 8px |
| `--sg-radius-chip` | 6px |
| `--sg-radius-tile` | 10px |
| `--sg-radius-card` | 12px |

Type: Sora only, weights 300, 400, 600, display sizes tracked -0.024em.
